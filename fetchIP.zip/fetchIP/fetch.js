const getUsers = () => {
    fetch("https://jsonplaceholder.typicode.com/users")
    .then((res) => {
        return res.json();
    })
    .then((data) => {
        data.forEach((user) => {
            const item = `<span class="cell">${user.name}</span><span class="cell">
            ${user.phone}</span><span class="cell"> ${user.email}</cell>`;
            document.getElementById("grid").insertAdjacentHTML("beforeend", item);
        });
    })
    .catch((error) => console.log(error));
};

//POST USER
const postUser = async () => {
    const nieuwUser = {
        name: "Adam",
    };
    try {
        const res = await fetch(" https://jsonplaceholder.typicode.com/users", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(nieuwUSer),
        });
        const data = await res.json();
        if (!res.ok) {
            console.log(data.description);
            return;
        }
    } catch (error) {
        console.log(error);
    }
};

