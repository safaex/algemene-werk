const vragen = document.querySelectorAll(".vraag");
const values = document.querySelectorAll(".value");

let maxVragen = vragen.lengt -1;

let huidigeVraag = 0;
values[huidigeVraag].style.backgroundColor = "#4bb543";

vragen.forEach ((vragen, indx) => {
    vraag.style.transform = `translateX(${indx * 100}%)`;
});

let volgendeVraag = document.querySelector("#btn-next");

volgendeVraag.addEventListener("click", function () {
    if (huidigeVraag < maxVragen) {
        huidigeVraag++;
    }

    values[huidigeVraag].style.backgroundColor = "#4bb543";
    vragen.forEach((vraag, indx) => {
        vraag.style.transform = `translateX(${100 * (indx - huidigeVraag)}%)`;
    });
});

const vorigeVraag = document.querySelector("#btn-prev");

vorigeVraag.addEventListener("click", function () {
    if (huidigeVraag > 0) {
        huidigeVraag--;
    }

    values[huidigeVraag+1].style.backgroundColor = "#ccc";

    vragen.forEach((vraag, indx) => {
        vraag.style.transform = `translateX(${100 * (indx - huidigeVraag)}%)`;
    });
});